
<?php $__env->startSection('add_category_product'); ?>
<div class="content-wrapper">
    <?php 
        session_start();
        $message = Session::get('message');
        if($message) {
            echo '<span class="text-alert">'.$message.'</span>';
            Session::put('message', null);
        }
    ?>
    <form action="<?php echo e(URL::to('/save-category-product')); ?>" method="POST">
        <div class="modal-body">
            <div class="form-group">
                <?php echo e(csrf_field()); ?>

                <label>Cate Name</label>
                <input type="text" name="cate_name" class="form-control" placeholder="Cate Name">
                <label>Cate Description</label>
                <textarea name="editor1" class="comment_content" ></textarea>

                <!-- <textarea name="cate_desc" id="" cols="100" rows="10"></textarea> -->
            </div>
        </div>
        
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="insertdata" class="btn btn-primary">Save data</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WhaleClothes\resources\views/admin/add_category_product.blade.php ENDPATH**/ ?>