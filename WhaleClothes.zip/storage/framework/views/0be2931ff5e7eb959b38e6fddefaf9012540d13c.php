
<?php $__env->startSection('checkout'); ?>
<div class="container my-5 py-4 border shipping-address">
	<div class="row shipping-heading">
		<div>
      <i  class="fa fa-map-marker"></i>
			<span>Địa chỉ nhận hàng</span>
		</div>
    <?php if($shipping->isEmpty()): ?>
		  <button class="btn btn-primary btn-add-address" data-toggle="modal" data-target="#shippingaddmodal">Thêm địa chỉ</button>
    <?php else: ?> 
    <button class="btn btn-primary btn-add-address" disabled data-toggle="modal" data-target="#shippingaddmodal">Thêm địa chỉ</button>
    <?php endif; ?>
	</div>
  <?php if($shipping->isEmpty()): ?>
    <div class="row mt-4 shipping-content">       
      <div>
        <span class="shipping-content-none">Vui lòng thêm địa chỉ nhận hàng</span>
      </div>      
    </div>
  <?php else: ?>
    <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <div class="row mt-4 shipping-content">
        <div>
          <span class="shipping-content-name"><?php echo e($value->fname); ?> <?php echo e($value->lname); ?></span>
          <span class="shipping-content-phone"><?php echo e($value->phone); ?></span>
          <span class="shipping-content-address"><?php echo e($value->address); ?></span>
          <span class="shipping-trash" style="margin-left: 150px;"><button class="btn" data-toggle="modal" data-target="#shippingdeletemodal"><i class="fa fa-trash" ></i></button></span>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</div>
<section class="cart_area section_padding my-5">
  <div class="container">
    <div class="cart_inner ">
      <div class="table-responsive">
        <form action="<?php echo e(URL::to('/save-checkout')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
          <?php if(!$shipping->isEmpty()): ?>
          <input type="hidden" name="shipping_id" value="<?php echo e($shipping[0]->id); ?>">
          <?php endif; ?>
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Size</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $total = 0; 
              ?>
              <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartEle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <div class="media">
                    <div class="d-flex">
                      <img src="<?php echo e(asset('/public/uploads/product/'.$cartEle->image)); ?>" alt="" />
                    </div>
                    <div class="media-body">
                      <p><?php echo e($cartEle->product_name); ?></p>
                    </div>
                  </div>
                </td>
                <td>
                  <h5>$<?php echo e($cartEle->price); ?></h5>
                </td>
                <td>
                  <div class="product_count">
                    <input class="input-number" readonly type="text" name="qty[<?php echo e($cartEle->id); ?>]" value="<?php echo e($cartEle->quantity); ?>">
                  </div>
                </td>
                <td>
                  <select name="size[<?php echo e($cartEle->id); ?>]" disabled class="custom-select">
                    <?php if($cartEle->size == 'S'): ?> 
                      <option value="S" selected>S</option>
                      <option value="M">M</option>
                      <option value="L">L</option>
                    <?php elseif($cartEle->size == 'M'): ?>
                      <option value="S">S</option>
                      <option value="M" selected>M</option>
                      <option value="L">L</option>
                    <?php else: ?> 
                      <option value="S">S</option>
                      <option value="M">M</option>
                      <option value="L" selected>L</option>
                      <?php endif; ?>
                  </select>
                </td>
                <td>
                  <h5>$<?php echo e($cartEle->price* $cartEle->quantity); ?></h5>
                </td>
              </tr>
              <?php 
                $total += $cartEle->price * $cartEle->quantity;
                Session::put('total', $total);
               ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <div class="container my-5 py-4 border payment-method">
          <div class="row payment-method-heading">
            <span class="payment-method-heading-title">Phương thức thanh toán</span>
          </div>
          <div class="row mt-4 payment-method-content">       
            <div class="payment-method-selection">
              <input label="Paypal" type="radio" name="method" value="Paypal">
              <input label="ShipCOD" type="radio" name="method" value="ShipCOD">
              <input label="Banking" type="radio" name="method" value="Banking">
            </div>      
          </div>
        </div>
        <div class="card-checkout card mb-4 w-50 float-right">
          <div class="card-header py-3">
              <h5 class="mb-0">Summary</h5>
          </div>
          <div class="card-body">
            <ul class="list-group list-group-flush">
                <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 pb-0">
                  Products
                  <span>$<?php echo e($total); ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                  Shipping
                  <span>Gratis</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 mb-3">
                  <div>
                      <strong>Total amount</strong>
                      <strong>
                      <p class="mb-0">(including VAT)</p>
                      </strong>
                  </div>
                  <span><strong>$<?php echo e($total); ?></strong></span>
                </li>
            </ul>
            <input type="hidden" name="total" value="<?php echo e($total); ?>">
            <?php if($cart->isEmpty()): ?>
            <button type="button" class="btn btn-primary btn-lg btn-block" data-toggle="modal" data-target="#nocartmodal">Make purchase</button>
            <?php else: ?>
            <button type="submit" class="btn btn-primary btn-lg btn-block">
              Make purchase
            </button>
            <?php endif; ?>
            <br>or<br>
            <a class="btn_1" href="<?php echo e(URL::to('/cart')); ?>">Comeback cart</a>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('add_shipping_modal'); ?>
<div class="modal fade" id="shippingaddmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add shipping address</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(URL::to('/save-shipping')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
        <div class="modal-body">
          <div class="form-group">
            <div class="form-row">
              <div class="col">
                <label>First name</label>
                <input type="text" name="fname" class="form-control" placeholder="First name">
              </div>
              <div class="col">
              <label>Last name</label>
            <input type="text" name="lname" class="form-control" placeholder="Last name">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" placeholder="Phone">
          </div>
          <div class="form-group">
            <label>Email address</label>
            <input type="text" name="email" class="form-control" placeholder="Email address">
          </div>
          <div class="form-group">
            <label>Address</label><br>
            <input type="text" name="address" class="form-control" placeholder="Address">
          </div>
        </div>
      
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" name="insertdata" class="btn btn-primary">Save data</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('delete_modal'); ?>
<div class="modal fade" id="shippingdeletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete product</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(URL::to('/delete-shipping')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="modal-body">
              <input type="hidden" name="del_shipping_id" id='del_shipping_id' value="<?php echo e($shipping[0]->id); ?>">
              <h4>Do you really want to delete this?</h4>
            </div>
          
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Wait a minute</button>
              <button type="submit" name="deletedata" class="btn btn-primary">Yes do it please :></button>
            </div>
          </form>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('no_cart_modal'); ?>
<div class="modal fade" id="nocartmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Vui lòng kiểm tra lại giỏ hàng trước khi thanh toán</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('display_modal'); ?>
<!-- <script type="text/javascript">
      $(document).ready(function() {
        $('.deletebtn').on('click', function() {
          $('#productdeletemodal').modal('show');

          $str = $(this).closest('tr');

          var data = $str.children('td').map(function() {
            return $(this).text();
          }).get();
          console.log(data);
          $('#del_product_id').val(data[0]);
        });
      });
    </script> -->

    <!-- <script type="text/javascript">
      $(document).ready(function() {
        $('.editbtn').on('click', function() {
          $('#producteditmodal').modal('show');

          $str = $(this).closest('tr');

          var data = $str.children('td').map(function() {
            return $(this).text();
          }).get();

          console.log(data);
          $('#update_product_id').val(data[0]);
          $('#update_product_name').val(data[1]);
          $('#update_product_desc').val(data[2]);
          $('#update_product_price').val(data[3]);
        });
      });
    </script> -->
<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('product_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WhaleClothes\resources\views/pages/checkout/show_checkout.blade.php ENDPATH**/ ?>