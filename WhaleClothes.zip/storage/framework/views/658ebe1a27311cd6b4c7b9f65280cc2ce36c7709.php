
<?php $__env->startSection('product_by_brand'); ?>
<section class="shop_section layout_padding">
        <div class="container">
            <div class="heading_container heading_center">
                <h2>
                Latest Watches
                </h2>
            </div>
            <div class="row">
              <div class="l-3 me-0 s-0">
                <div class="bl_left">
                    <div class="cate_heading text-center">
                        <h3>Category</h3>
                    </div>
                    <div class="list-group">
                        <?php $__currentLoopData = $all_category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(URL::to('/category/'.$category->id)); ?>" class="list-group-item list-group-item-action"><?php echo e($category->category_name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="bl_left">
                  <div class="cate_heading text-center">
                      <h3>Brand</h3>
                  </div>
                  <div class="list-group">
                      <?php $__currentLoopData = $all_brand_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e(URL::to('/brand/'.$brand->id)); ?>" class="list-group-item list-group-item-action"><?php echo e($brand->brand_name); ?></a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
            <div class="col-xl-9 col-md-12">
              <div class="row" id="content">
                <?php $__currentLoopData = $product_by_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-xl-4">
                    <div class="box">
                        <a href="<?php echo e(URL::to('/product-detail/'.$product->id)); ?>">
                        <div class="img-box">
                            <img src="<?php echo e(asset('/public/uploads/product/'.$product->image)); ?>" alt="">
                        </div>
                        <div class="detail-box">
                            <h6><?php echo e($product->product_name); ?></h6>
                            <h6>
                            Price:
                            <span><?php echo e($product->price); ?>$</span>
                            </h6>
                        </div>
                        <div class="new">
                            <span> New </span>
                        </div>
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                <div class="row">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                        <?php 
                            // if(isset($pages)) {
                            // for($i=1; $i<=$pages; $i++) {
                            // echo "<li class='page-item'><a class='page-link' href='?page=".$i."'>".$i."</a></li> ";
                            // }}
                            ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>         



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('product_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WhaleClothes\resources\views/pages/brand/show_brand.blade.php ENDPATH**/ ?>