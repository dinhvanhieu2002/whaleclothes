
<?php $__env->startSection('cart'); ?>
<section class="cart_area section_padding my-5">
  <div class="container">
    <div class="cart_inner ">
      <div class="table-responsive">
        <form action="<?php echo e(URL::to('/update-cart')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <table class="table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Size</th>
                <th scope="col">Total</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $total = 0; 
              ?>
              <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartEle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <div class="media">
                    <div class="d-flex">
                      <img src="<?php echo e(asset('/public/uploads/product/'.$cartEle->image)); ?>" alt="" />
                    </div>
                    <div class="media-body">
                      <p><?php echo e($cartEle->product_name); ?></p>
                    </div>
                  </div>
                </td>
                <td>
                  <h5>$<?php echo e($cartEle->price); ?></h5>
                </td>
                <td>
                  <div class="product_count">
                    <input class="input-number" type="text" name="qty[<?php echo e($cartEle->id); ?>]" value="<?php echo e($cartEle->quantity); ?>">
                  </div>
                </td>
                <td>
                  <select name="size[<?php echo e($cartEle->id); ?>]" class="custom-select">
                    <?php if($cartEle->size == 'S'): ?> 
                      <option value="S" selected>S</option>
                      <option value="M">M</option>
                      <option value="L">L</option>
                    <?php elseif($cartEle->size == 'M'): ?>
                      <option value="S">S</option>
                      <option value="M" selected>M</option>
                      <option value="L">L</option>
                    <?php else: ?> 
                      <option value="S">S</option>
                      <option value="M">M</option>
                      <option value="L" selected>L</option>
                      <?php endif; ?>
                  </select>
                </td>
                <td>
                  <h5>$<?php echo e($cartEle->price* $cartEle->quantity); ?></h5>
                </td>
                <td>
                  <a href="<?php echo e(URL::to('/delete-cart/'.$cartEle->id)); ?>" class="delcart"><i class="fa fa-times"></i></a>
                </td>
              </tr>
              <?php 
                
                $total += $cartEle->price * $cartEle->quantity;
               ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr class="bottom_button">
              <td style="text-align: left;">
                <input type="submit" name="submit" value="Update cart" class="btn_1">
              </td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td>
                <h5>Subtotal</h5>
              </td>
              <td>
                <h5>$<?php echo e($total); ?></h5>
              </td>
            </tr>
          </tbody>
        </table>
    </form>
      <div class="checkout_btn_inner float-right">
        <a class="btn_1" href="<?php echo e(URL::to('/products')); ?>">Continue Shopping</a>
        <a class="btn_1 checkout_btn_1" href="<?php echo e(URL::to('/checkout')); ?>">Proceed to checkout</a>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('product_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WhaleClothes\resources\views/pages/cart/show_cart.blade.php ENDPATH**/ ?>