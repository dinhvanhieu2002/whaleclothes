
<?php $__env->startSection('admin_content'); ?>
<div class="content-wrapper">
    Hi Admin!
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WhaleClothes\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>