
<?php $__env->startSection('order_detail'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Order detail</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">  
                        <table class="table table-light">
                            <thead>
                                <tr>
                                    <th scope="col">Product name</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Size</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $all_order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order_detail->product_name); ?></td>
                                    <td class="pro-img"><img src="<?php echo e(asset('/public/uploads/product/'.$order_detail->image)); ?>" alt=""></td>
                                    <td><?php echo e($order_detail->price); ?>$</td>
                                    <td><?php echo e($order_detail->quantity); ?></td>
                                    <td><?php echo e($order_detail->size); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WhaleClothes\resources\views/admin/order_detail.blade.php ENDPATH**/ ?>