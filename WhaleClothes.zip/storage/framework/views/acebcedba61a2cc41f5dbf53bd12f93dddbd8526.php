<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">

  <title>Timups</title>


  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/frontend/css/bootstrap.css')); ?>" />
  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- font awesome style -->
  <link href="<?php echo e(asset('/public/frontend/css/font-awesome.min.css')); ?>" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('/public/frontend/css/style.css')); ?>" rel="stylesheet" />
  <!-- responsive style -->
  <link href="<?php echo e(asset('/public/frontend/css/responsive.css')); ?>" rel="stylesheet" />

</head>

<body class="sub_page">

  <div class="hero_area">
    <header class="header_section">
    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>">
            <span>
              <img width="50" height="50" src="<?php echo e(asset('/public/frontend/images/logo.png')); ?>" alt="">

              WhaleClothes
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(URL::to('/')); ?>">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(URL::to('/products')); ?>"> Clothes </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php"> About </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.php">Contact Us</a>
              </li>
            </ul>
            
            <div class="user_option-box">
              <form action="" method="POST">
                <input type="text" name="search-text" class="search-txt" placeholder="Search">
                <button type="submit" id="search-btn" on>
                  <i class="fa fa-search" aria-hidden="true"></i>
                </button>
                <a href="cart.php">
                  <i class="fa fa-cart-plus" aria-hidden="true"></i>
                </a>
                <?php if(Session::get('user_id')): ?>
                <a href="<?php echo e(URL::to('/logout')); ?>">
                  <i class='fa fa-power-off' aria-hidden='true'></i>
                </a>
                <?php else: ?>
                <a href="<?php echo e(URL::to('/login')); ?>">
                  <i class='fa fa-user' aria-hidden='true'></i>
                </a>
                <?php endif; ?>
                
              </form>    
            </div>
          </div>
        </nav>
      </div>
    </header>
  </div>
  <section class="login_part section_padding ">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 col-md-6">
          <div class="login_part_text text-center">
            <div class="login_part_text_iner">
              <h2>To be an close customer</h2>
              <p>There are product being made in science and technology
              everyday, and a good example of this is the</p>
              <a href="register.php" class="btn_3">Create an Account</a>
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6">
          <div class="login_part_form">
            <div class="login_part_form_iner">
              <h3>Welcome to my shop ! <br>
              Please Sign up now</h3>
              <form class="row contact_form" action="<?php echo e(URL::to('/execute-signup')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-12 form-group p_star">
                  <input type="text" class="form-control" id="fullname" name="fullname" value="" placeholder="Fullname">
                </div>
                <div class="col-md-12 form-group p_star">
                  <input type="text" class="form-control" id="username" name="username" value="" placeholder="Username">
                </div>
                <div class="col-md-12 form-group p_star">
                  <input type="password" class="form-control" id="password" name="password" value="" placeholder="Password">
                </div>
                <div class="col-md-12 form-group p_star">
                  <input type="text" class="form-control" id="email" name="email" value="" placeholder="Email">
                </div>
                <div class="col-md-12 form-group p_star">
                  <input type="tel" class="form-control" id="phone" name="phone" value="" placeholder="Phone number">
                </div>
                <div class="col-md-12 form-group">
                  <button type="submit" value="submit" class="btn btn-primary center" >
                    Sign up
                  </button>
                </div>
                <?php
                    $message = Session::get('error_signup');
                    if($message) {
                      echo $message;
                      Session::put('error_signup', null);
                    }
                  ?>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- footer section -->
  <footer class="footer_section">
        <div class="container">
            <div class="row">
            <div class="col-md-6 col-lg-3 footer-col">
                <div class="footer_detail">
                <h4>
                    About
                </h4>
                <p>
                    Necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with
                </p>
                <div class="footer_social">
                    <a href="">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                    <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                    <a href="">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                    </a>
                    <a href="">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                    </a>
                </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 footer-col">
                <div class="footer_contact">
                <h4>
                    Reach at..
                </h4>
                <div class="contact_link_box">
                    <a href="">
                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                    <span>
                        Location
                    </span>
                    </a>
                    <a href="">
                    <i class="fa fa-phone" aria-hidden="true"></i>
                    <span>
                        Call +01 1234567890
                    </span>
                    </a>
                    <a href="">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                    <span>
                        demo@gmail.com
                    </span>
                    </a>
                </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 footer-col">
                <div class="footer_contact">
                <h4>
                    Subscribe
                </h4>
                <form action="#">
                    <input type="text" placeholder="Enter email" />
                    <button type="submit">
                    Subscribe
                    </button>
                </form>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 footer-col">
                <div class="map_container">
                <div class="map">
                    <div id="googleMap"></div>
                </div>
                </div>
            </div>
            </div>
            <div class="footer-info">
            <p>
                &copy; <span id="displayYear"></span> All Rights Reserved By
                <a href="https://html.design/">Free Html Templates</a>
            </p>
            </div>
        </div>
    </footer>
  <!-- footer section -->

  <!-- jQery -->
  <script src="<?php echo e(asset('/public/frontend/js/jquery-3.4.1.min.js')); ?>"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script src="<?php echo e(asset('/public/frontend/js/bootstrap.js')); ?>"></script>
  <!-- owl slider -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- custom js -->
  <script src="<?php echo e(asset('/public/frontend/js/custom.js')); ?>"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap"></script>
  <!-- End Google Map -->

</body>

</html><?php /**PATH C:\xampp\htdocs\WhaleClothes\resources\views/pages/signup.blade.php ENDPATH**/ ?>