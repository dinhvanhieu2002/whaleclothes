@extends('admin_layout')
@section('admin_content')
<div class="content-wrapper">
    Hi Admin!
</div>
@endsection